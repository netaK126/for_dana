import argparse
import time
import os
import torch
import numpy as np
import pickle
use_cuda = torch.cuda.is_available()
dtype = torch.float32 if use_cuda else torch.float64
device_id = "cuda:0" if use_cuda else "cpu"
import warnings
warnings.filterwarnings("ignore")
procs = []

def flatten_params(dict):
    if dict is None:
        return 0
    f = ()
    for _, t in dict.items():
        f = f + (t.view(-1),)
    return torch.cat(f)

def vec2dict(w, dict):
    d = {}
    i = 0
    for x, t in dict.items():
        l = len(t.view(-1))
        d[x] = w[i:i + l].view(t.size())
        i += l
    return d

def load_hyper_dataset(models_path, dataset, device='cpu'):
    print('device:', device)
    train_set = torch.load('./datasets/' + dataset + '/train.pth')
    N = len(train_set[1])
    path = models_path + dataset
    model = torch.load(path + '.pth', map_location=torch.device(device))
    if os.path.exists(path+'W_all.pth'):
        W = torch.load(path+'W_all.pth')
    else:
        W = (flatten_params(model).unsqueeze(0),)
        for i in range(N):
            print('\r{:5.2f}%'.format(100 * i / N), end='')
            model = torch.load(path + str(i) + '.pth', map_location=torch.device(device))
            W = W + (flatten_params(model).unsqueeze(0),)
        print('\rdone!')
        W = torch.cat(W, dim=0)
        torch.save(W, path+'W_all.pth')
    w_rel = W + 0.0
    w_indexes = []
    results = []
    return W, w_rel, model, w_indexes, results


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Privacy Example',  formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument('--dataset', type=str, default="twitter", help='Dataset: twitter, crypto, adult, or credit.')
    parser.add_argument('--models_path', type=str, default="./models/", help='Path of the models.')
    parser.add_argument('--models_indexes', type=str, default="all",
                        help='Indexes of models to include in the hypernetowrk. all to include all of them and 1,2,3 to include only first three networks')

    args = parser.parse_args()
    dataset = args.dataset
    models_path = args.models_path
    models_indexes = args.models_indexes

    W, w_rel, model, w_indexes, results = load_hyper_dataset(models_path, dataset)
    print(W.shape)

    if models_indexes == "all":
        cl = np.ones(len(w_rel.numpy()))
    else:
        models_indexes = models_indexes.split(",")
        models_indexes = [int(i) for i in models_indexes]
        cl = np.zeros(len(w_rel.numpy()))
        cl[models_indexes] = 1

    network_ind_rel = np.arange(W.shape[0])
    wmin, _ = w_rel[cl == 1, :].min(dim=0)
    wmax, _ = w_rel[cl == 1, :].max(dim=0)
    dmin = vec2dict(wmin, model)
    dmax = vec2dict(wmax, model)

    a = []
    for (i, j) in dmin.items():
        a.append(np.transpose(j.cpu().detach().numpy()))
    for i in a:
        pickle.dump(a, open(models_path + '/hypernetwork_min_box.p', "wb"))
    a = []
    for (i, j) in dmax.items():
        a.append(np.transpose(j.cpu().detach().numpy()))
    for i in a:
        pickle.dump(a, open(models_path + '/hypernetwork_max_box.p', "wb"))






















